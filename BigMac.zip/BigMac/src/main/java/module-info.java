module hu.unideb.inf.sde.yazan.bigmac {
    requires javafx.controls;
    requires javafx.fxml;


    opens hu.unideb.inf.sde.yazan.bigmac to javafx.fxml;
    exports hu.unideb.inf.sde.yazan.bigmac;
}